﻿Public Class FormMenuUtama
    Private Sub Slide7ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Slide7ToolStripMenuItem.Click
        FormOperatorRelasi.Show()
    End Sub

    Private Sub PesanToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PesanToolStripMenuItem.Click
        FormPesan.Show()
    End Sub

    Private Sub Slide4ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Slide4ToolStripMenuItem.Click
        FormIFThen.Show()
    End Sub

    Private Sub Slide18ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Slide18ToolStripMenuItem.Click
        FormPesan2.Show()
    End Sub

    Private Sub Slide12ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Slide12ToolStripMenuItem.Click
        FormKurs.Show()
    End Sub

    Private Sub Slide14ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Slide14ToolStripMenuItem.Click
        FormAritmatika.Show()
    End Sub

    Private Sub Slide15ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Slide15ToolStripMenuItem.Click
        FormAritmatika2.Show()
    End Sub

    Private Sub Slide16ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Slide16ToolStripMenuItem.Click
        FormKonversi.Show()
    End Sub

    Private Sub Slide9ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Slide9ToolStripMenuItem.Click
        FormRadioButton.Show()
    End Sub

    Private Sub Slide14ToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles Slide14ToolStripMenuItem1.Click
        FormComboBox.Show()
    End Sub

    Private Sub Slide17ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Slide17ToolStripMenuItem.Click
        FormNestedif.Show()
    End Sub

    Private Sub EntryDataMahasiswaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EntryDataMahasiswaToolStripMenuItem.Click
        FormEntryData.Show()
    End Sub

    Private Sub MenghitungNilaiMahasiswaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MenghitungNilaiMahasiswaToolStripMenuItem.Click
        FormHitungNilai.Show()
    End Sub
    Private Sub CaseMenggunakanListBoxToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CaseMenggunakanListBoxToolStripMenuItem.Click
        FormListBox.Show()
    End Sub

    Private Sub ToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem1.Click
        FormCaseCmb.Show()
    End Sub

    Private Sub ToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem2.Click
        FormTextBox.Show()
    End Sub

    Private Sub CaseMenggunakanButtonToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CaseMenggunakanButtonToolStripMenuItem.Click
        FormButton.Show()
    End Sub

    Private Sub PenghitunganNilaiAkhirDanGradeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PenghitunganNilaiAkhirDanGradeToolStripMenuItem.Click
        FormNilaiAkhir.Show()
    End Sub

    Private Sub GajiKaryawanToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GajiKaryawanToolStripMenuItem.Click
        FormGaji.Show()
    End Sub

    Private Sub Slide10ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Slide10ToolStripMenuItem.Click
        FormChkBox.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim keluar As String
        keluar = MsgBox("Apakah anda ingin keluar dari program??", MsgBoxStyle.Question + MsgBoxStyle.OkCancel, "Exit")
        If keluar = vbOK Then
            Me.Close()
        End If
    End Sub

    Private Sub FormMenuUtama_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Slide3ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Slide3ToolStripMenuItem.Click
        Pfornext.Show()
    End Sub

    Private Sub Slide4ToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles Slide4ToolStripMenuItem1.Click
        Pforback.Show()
    End Sub

    Private Sub Slide5ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Slide5ToolStripMenuItem.Click
        Ptanggal.Show()
    End Sub

    Private Sub Slide6ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Slide6ToolStripMenuItem.Click
        Pjumlah.Show()
    End Sub

    Private Sub ToolStripMenuItem3_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem3.Click
        Platihan.Show()
    End Sub
End Class
