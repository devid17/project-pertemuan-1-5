﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormHitungNilai
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TxtNA = New System.Windows.Forms.TextBox()
        Me.TxtTugas = New System.Windows.Forms.TextBox()
        Me.TxtUTS = New System.Windows.Forms.TextBox()
        Me.TxtUAS = New System.Windows.Forms.TextBox()
        Me.TxtHasilNA = New System.Windows.Forms.TextBox()
        Me.TxtHasilTugas = New System.Windows.Forms.TextBox()
        Me.TxtHasilUTS = New System.Windows.Forms.TextBox()
        Me.TxtHasilUAS = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.TxtTotal = New System.Windows.Forms.TextBox()
        Me.TxtGrade = New System.Windows.Forms.TextBox()
        Me.TxtKet = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(165, 33)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(142, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Menghitung Nilai Mahasiswa"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(55, 89)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(60, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Nilai Absen"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(55, 117)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(60, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Nilai Tugas"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(55, 148)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(58, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Nialai UTS"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(55, 179)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(52, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Nilai UAS"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(288, 89)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(27, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "10%"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(288, 117)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(27, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "20%"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(288, 148)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(27, 13)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "30%"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(288, 179)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(27, 13)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "40%"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(288, 255)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(54, 13)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "Total Nilai"
        '
        'TxtNA
        '
        Me.TxtNA.Location = New System.Drawing.Point(144, 84)
        Me.TxtNA.Name = "TxtNA"
        Me.TxtNA.Size = New System.Drawing.Size(100, 20)
        Me.TxtNA.TabIndex = 10
        '
        'TxtTugas
        '
        Me.TxtTugas.Location = New System.Drawing.Point(144, 110)
        Me.TxtTugas.Name = "TxtTugas"
        Me.TxtTugas.Size = New System.Drawing.Size(100, 20)
        Me.TxtTugas.TabIndex = 11
        '
        'TxtUTS
        '
        Me.TxtUTS.Location = New System.Drawing.Point(144, 145)
        Me.TxtUTS.Name = "TxtUTS"
        Me.TxtUTS.Size = New System.Drawing.Size(100, 20)
        Me.TxtUTS.TabIndex = 12
        '
        'TxtUAS
        '
        Me.TxtUAS.Location = New System.Drawing.Point(144, 176)
        Me.TxtUAS.Name = "TxtUAS"
        Me.TxtUAS.Size = New System.Drawing.Size(100, 20)
        Me.TxtUAS.TabIndex = 13
        '
        'TxtHasilNA
        '
        Me.TxtHasilNA.Enabled = False
        Me.TxtHasilNA.Location = New System.Drawing.Point(343, 84)
        Me.TxtHasilNA.Name = "TxtHasilNA"
        Me.TxtHasilNA.Size = New System.Drawing.Size(100, 20)
        Me.TxtHasilNA.TabIndex = 14
        '
        'TxtHasilTugas
        '
        Me.TxtHasilTugas.Enabled = False
        Me.TxtHasilTugas.Location = New System.Drawing.Point(343, 114)
        Me.TxtHasilTugas.Name = "TxtHasilTugas"
        Me.TxtHasilTugas.Size = New System.Drawing.Size(100, 20)
        Me.TxtHasilTugas.TabIndex = 15
        '
        'TxtHasilUTS
        '
        Me.TxtHasilUTS.Enabled = False
        Me.TxtHasilUTS.Location = New System.Drawing.Point(343, 148)
        Me.TxtHasilUTS.Name = "TxtHasilUTS"
        Me.TxtHasilUTS.Size = New System.Drawing.Size(100, 20)
        Me.TxtHasilUTS.TabIndex = 16
        '
        'TxtHasilUAS
        '
        Me.TxtHasilUAS.Enabled = False
        Me.TxtHasilUAS.Location = New System.Drawing.Point(343, 179)
        Me.TxtHasilUAS.Name = "TxtHasilUAS"
        Me.TxtHasilUAS.Size = New System.Drawing.Size(100, 20)
        Me.TxtHasilUAS.TabIndex = 17
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(58, 255)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 18
        Me.Button1.Text = "Hitung"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(58, 284)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 19
        Me.Button2.Text = "Ulang"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(144, 255)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(73, 51)
        Me.Button3.TabIndex = 20
        Me.Button3.Text = "Keluar"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(288, 274)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(36, 13)
        Me.Label11.TabIndex = 21
        Me.Label11.Text = "Grade"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(288, 294)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(62, 13)
        Me.Label12.TabIndex = 22
        Me.Label12.Text = "Keterangan"
        '
        'TxtTotal
        '
        Me.TxtTotal.Location = New System.Drawing.Point(356, 252)
        Me.TxtTotal.Name = "TxtTotal"
        Me.TxtTotal.Size = New System.Drawing.Size(87, 20)
        Me.TxtTotal.TabIndex = 23
        '
        'TxtGrade
        '
        Me.TxtGrade.Location = New System.Drawing.Point(356, 271)
        Me.TxtGrade.Name = "TxtGrade"
        Me.TxtGrade.Size = New System.Drawing.Size(87, 20)
        Me.TxtGrade.TabIndex = 24
        '
        'TxtKet
        '
        Me.TxtKet.Location = New System.Drawing.Point(356, 291)
        Me.TxtKet.Name = "TxtKet"
        Me.TxtKet.Size = New System.Drawing.Size(87, 20)
        Me.TxtKet.TabIndex = 25
        '
        'FormHitungNilai
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Tugas_VB_Pertemuan_1_14.My.Resources.Resources._803_x_450_
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.TxtKet)
        Me.Controls.Add(Me.TxtGrade)
        Me.Controls.Add(Me.TxtTotal)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TxtHasilUAS)
        Me.Controls.Add(Me.TxtHasilUTS)
        Me.Controls.Add(Me.TxtHasilTugas)
        Me.Controls.Add(Me.TxtHasilNA)
        Me.Controls.Add(Me.TxtUAS)
        Me.Controls.Add(Me.TxtUTS)
        Me.Controls.Add(Me.TxtTugas)
        Me.Controls.Add(Me.TxtNA)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "FormHitungNilai"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Program Menghitung Nilai Mahasiswa"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents TxtNA As TextBox
    Friend WithEvents TxtTugas As TextBox
    Friend WithEvents TxtUTS As TextBox
    Friend WithEvents TxtUAS As TextBox
    Friend WithEvents TxtHasilNA As TextBox
    Friend WithEvents TxtHasilTugas As TextBox
    Friend WithEvents TxtHasilUTS As TextBox
    Friend WithEvents TxtHasilUAS As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents TxtTotal As TextBox
    Friend WithEvents TxtGrade As TextBox
    Friend WithEvents TxtKet As TextBox
End Class
