﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormRadioButton
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.RBSate = New System.Windows.Forms.RadioButton()
        Me.RBSoto = New System.Windows.Forms.RadioButton()
        Me.RBKare = New System.Windows.Forms.RadioButton()
        Me.BtTampil = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'RBSate
        '
        Me.RBSate.AutoSize = True
        Me.RBSate.Location = New System.Drawing.Point(6, 19)
        Me.RBSate.Name = "RBSate"
        Me.RBSate.Size = New System.Drawing.Size(47, 17)
        Me.RBSate.TabIndex = 1
        Me.RBSate.TabStop = True
        Me.RBSate.Text = "Sate"
        Me.RBSate.UseVisualStyleBackColor = True
        '
        'RBSoto
        '
        Me.RBSoto.AutoSize = True
        Me.RBSoto.Location = New System.Drawing.Point(6, 52)
        Me.RBSoto.Name = "RBSoto"
        Me.RBSoto.Size = New System.Drawing.Size(47, 17)
        Me.RBSoto.TabIndex = 2
        Me.RBSoto.TabStop = True
        Me.RBSoto.Text = "Soto"
        Me.RBSoto.UseVisualStyleBackColor = True
        '
        'RBKare
        '
        Me.RBKare.AutoSize = True
        Me.RBKare.Location = New System.Drawing.Point(6, 91)
        Me.RBKare.Name = "RBKare"
        Me.RBKare.Size = New System.Drawing.Size(47, 17)
        Me.RBKare.TabIndex = 3
        Me.RBKare.TabStop = True
        Me.RBKare.Text = "Kare"
        Me.RBKare.UseVisualStyleBackColor = True
        '
        'BtTampil
        '
        Me.BtTampil.Location = New System.Drawing.Point(28, 197)
        Me.BtTampil.Name = "BtTampil"
        Me.BtTampil.Size = New System.Drawing.Size(121, 23)
        Me.BtTampil.TabIndex = 4
        Me.BtTampil.Text = "Tampilkan Pilihan"
        Me.BtTampil.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.RBSate)
        Me.GroupBox1.Controls.Add(Me.RBSoto)
        Me.GroupBox1.Controls.Add(Me.RBKare)
        Me.GroupBox1.Location = New System.Drawing.Point(28, 34)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(200, 114)
        Me.GroupBox1.TabIndex = 5
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Makanan Favorit"
        '
        'FormRadioButton
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.BtTampil)
        Me.Name = "FormRadioButton"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Program If..Else..End If dengan RadioButton"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents RBSate As RadioButton
    Friend WithEvents RBSoto As RadioButton
    Friend WithEvents RBKare As RadioButton
    Friend WithEvents BtTampil As Button
    Friend WithEvents GroupBox1 As GroupBox
End Class
