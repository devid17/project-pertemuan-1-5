﻿Public Class FormTextBox
    Private Sub TxtKode_TextChanged(sender As Object, e As EventArgs) Handles TxtKode.TextChanged
        Select Case TxtKode.Text
            Case "SI"
                LblJur.Text = "Sistem Informasi"
                LblPro.Text = "Sastra-1"
            Case "TI"
                LblJur.Text = "Teknik Informatika"
                LblPro.Text = "Sastra-1"
            Case Else
                LblJur.Text = "Jurusan Belum terdaftar"

        End Select
    End Sub
End Class