﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormChkBox
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.ChkKare = New System.Windows.Forms.CheckBox()
        Me.ChkSoto = New System.Windows.Forms.CheckBox()
        Me.ChkSate = New System.Windows.Forms.CheckBox()
        Me.BtTampil = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.ChkKare)
        Me.GroupBox1.Controls.Add(Me.ChkSoto)
        Me.GroupBox1.Controls.Add(Me.ChkSate)
        Me.GroupBox1.Location = New System.Drawing.Point(24, 28)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(200, 114)
        Me.GroupBox1.TabIndex = 7
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Makanan Favorit"
        '
        'ChkKare
        '
        Me.ChkKare.AutoSize = True
        Me.ChkKare.Location = New System.Drawing.Point(6, 91)
        Me.ChkKare.Name = "ChkKare"
        Me.ChkKare.Size = New System.Drawing.Size(48, 17)
        Me.ChkKare.TabIndex = 10
        Me.ChkKare.Text = "Kare"
        Me.ChkKare.UseVisualStyleBackColor = True
        '
        'ChkSoto
        '
        Me.ChkSoto.AutoSize = True
        Me.ChkSoto.Location = New System.Drawing.Point(6, 54)
        Me.ChkSoto.Name = "ChkSoto"
        Me.ChkSoto.Size = New System.Drawing.Size(48, 17)
        Me.ChkSoto.TabIndex = 9
        Me.ChkSoto.Text = "Soto"
        Me.ChkSoto.UseVisualStyleBackColor = True
        '
        'ChkSate
        '
        Me.ChkSate.AutoSize = True
        Me.ChkSate.Location = New System.Drawing.Point(6, 19)
        Me.ChkSate.Name = "ChkSate"
        Me.ChkSate.Size = New System.Drawing.Size(48, 17)
        Me.ChkSate.TabIndex = 8
        Me.ChkSate.Text = "Sate"
        Me.ChkSate.UseVisualStyleBackColor = True
        '
        'BtTampil
        '
        Me.BtTampil.Location = New System.Drawing.Point(24, 172)
        Me.BtTampil.Name = "BtTampil"
        Me.BtTampil.Size = New System.Drawing.Size(121, 23)
        Me.BtTampil.TabIndex = 6
        Me.BtTampil.Text = "Tampilkan Pilihan"
        Me.BtTampil.UseVisualStyleBackColor = True
        '
        'FormChkBox
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Tugas_VB_Pertemuan_1_14.My.Resources.Resources._803_x_450_3
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.BtTampil)
        Me.Name = "FormChkBox"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Program If..Else..End If dengan CheckBox"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents BtTampil As Button
    Friend WithEvents ChkKare As CheckBox
    Friend WithEvents ChkSoto As CheckBox
    Friend WithEvents ChkSate As CheckBox
End Class
