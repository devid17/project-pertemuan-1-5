﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormIFThen
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.CmdProses = New System.Windows.Forms.Button()
        Me.TxtKet = New System.Windows.Forms.TextBox()
        Me.TxtNA = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'CmdProses
        '
        Me.CmdProses.Location = New System.Drawing.Point(112, 102)
        Me.CmdProses.Name = "CmdProses"
        Me.CmdProses.Size = New System.Drawing.Size(75, 23)
        Me.CmdProses.TabIndex = 9
        Me.CmdProses.Text = "Prosses"
        Me.CmdProses.UseVisualStyleBackColor = True
        '
        'TxtKet
        '
        Me.TxtKet.Enabled = False
        Me.TxtKet.Location = New System.Drawing.Point(188, 150)
        Me.TxtKet.Name = "TxtKet"
        Me.TxtKet.Size = New System.Drawing.Size(100, 20)
        Me.TxtKet.TabIndex = 8
        '
        'TxtNA
        '
        Me.TxtNA.Location = New System.Drawing.Point(188, 59)
        Me.TxtNA.Name = "TxtNA"
        Me.TxtNA.Size = New System.Drawing.Size(100, 20)
        Me.TxtNA.TabIndex = 7
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(44, 157)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(62, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Keterangan"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(44, 59)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(54, 13)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Nilai Akhir"
        '
        'FormIFThen
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Tugas_VB_Pertemuan_1_14.My.Resources.Resources._803_x_450_
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.CmdProses)
        Me.Controls.Add(Me.TxtKet)
        Me.Controls.Add(Me.TxtNA)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "FormIFThen"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Program If Then"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents CmdProses As Button
    Friend WithEvents TxtKet As TextBox
    Friend WithEvents TxtNA As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
End Class
