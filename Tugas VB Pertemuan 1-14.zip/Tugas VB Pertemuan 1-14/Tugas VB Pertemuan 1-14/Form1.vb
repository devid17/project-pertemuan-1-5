﻿Public Class Pfornext
    Private Sub CmdProses_Click(sender As Object, e As EventArgs) Handles CmdProses.Click
        Dim i As Integer
        ListBox1.Items.Clear()
        For i = 1 To 10
            ListBox1.Items.Add(i)
        Next
    End Sub
End Class