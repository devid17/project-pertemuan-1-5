﻿Public Class FormHitungNilai
    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        TxtHasilNA.Text = 0.1 * Val(TxtNA.Text)
        TxtHasilTugas.Text = 0.2 * Val(TxtTugas.Text)
        TxtHasilUTS.Text = 0.3 * Val(TxtUTS.Text)
        TxtHasilUAS.Text = 0.4 * Val(TxtUAS.Text)

        TxtTotal.Text = Val(TxtHasilNA.Text) + Val(TxtHasilTugas.Text) + Val(TxtHasilUTS.Text) + Val(TxtHasilUAS.Text)

        If TxtTotal.Text <= 56 Then
            TxtGrade.Text = "E"
            TxtKet.Text = "Gagal"
        ElseIf TxtTotal.Text <= 65 Then
            TxtGrade.Text = "D"
            TxtKet.Text = "Gagal"
        ElseIf TxtTotal.Text <= 75 Then
            TxtGrade.Text = "C"
            TxtKet.Text = "Lulus"
        ElseIf TxtTotal.Text <= 85 Then
            TxtGrade.Text = "B"
            TxtKet.Text = "Lulus"
        ElseIf TxtTotal.Text > 85 Then
            TxtGrade.Text = "A"
            TxtKet.Text = "Lulus"
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TxtNA.Text = ""
        TxtTugas.Text = ""
        TxtUTS.Text = ""
        TxtUAS.Text = ""
        TxtHasilNA.Text = ""
        TxtHasilTugas.Text = ""
        TxtHasilUTS.Text = ""
        TxtHasilUAS.Text = ""
        TxtTotal.Text = ""
        TxtGrade.Text = ""
        TxtKet.Text = ""

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim pesan As String
        pesan = MsgBox("Apakah Anda Ingin Keluar??", MsgBoxStyle.Question + MsgBoxStyle.OkCancel, "Exit")
        If pesan = vbOK Then
            Me.Close()
        End If
    End Sub
End Class