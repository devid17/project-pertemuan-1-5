﻿Public Class FormAritmatika2
    Dim nilai1, nilai2 As Double
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        On Error GoTo salah
        nilai1 = TextBox1.Text
        nilai2 = TextBox2.Text

        If RadioButton1.Checked = True Then
            TextBox3.Text = nilai1 / nilai2
        End If
        If RadioButton2.Checked = True Then
            TextBox3.Text = nilai1 Mod nilai2
        End If
        If RadioButton3.Checked = True Then
            TextBox3.Text = nilai1 ^ nilai2
        End If
        If RadioButton4.Checked = True Then
            TextBox3.Text = nilai1 & nilai2
        End If
        Exit Sub
salah:  MsgBox("Data yang anda masukkan kurang lengkap")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim pesan As String
        pesan = MsgBox("Apakah anda ingin keluar dari program??", MsgBoxStyle.Question + MsgBoxStyle.OkCancel, "Exit")
        If pesan = vbOK Then
            Me.Close()
        End If
    End Sub
End Class