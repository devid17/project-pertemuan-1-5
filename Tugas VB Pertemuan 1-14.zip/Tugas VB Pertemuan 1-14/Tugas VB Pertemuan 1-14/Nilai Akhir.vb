﻿Public Class FormNilaiAkhir
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        TxtNA.Text = 0.2 * Val(TxtNTgs.Text) + 0.3 * Val(TxtNUTS.Text) + 0.5 * Val(TxtNUAS.Text)
        Select Case TxtNA.Text
            Case Is > 85
                TxtGrade.Text = "A"
            Case Is <= 85
                TxtGrade.Text = "B"
            Case Is <= 75
                TxtGrade.Text = "C"
            Case Is <= 65
                TxtGrade.Text = "D"
            Case Is <= 56
                TxtGrade.Text = "E"
        End Select
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Label10.Text = TxtNAMA.Text
        Label14.Text = TxtNPM.Text
        Label17.Text = TxtJur.Text
        Label18.Text = TxtNA.Text
        Label19.Text = TxtGrade.Text
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TxtNAMA.Text = ""
        TxtNPM.Text = ""
        TxtJur.Text = ""
        TxtNTgs.Text = ""
        TxtNUTS.Text = ""
        TxtNUAS.Text = ""
        TxtNA.Text = ""
        TxtGrade.Text = ""
        Label10.Text = ""
        Label14.Text = ""
        Label17.Text = ""
        Label18.Text = ""
        Label19.Text = ""
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim keluar As String
        keluar = MsgBox("Apakah Anda Ingin Keluar??", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Exit")
        If keluar = MsgBoxResult.Yes Then
            Me.Close()
        End If
    End Sub
End Class