﻿Public Class FormKurs
    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged
        Label4.Text = "Rp. " & Val(TextBox1.Text) * Val(TextBox2.Text)
    End Sub
End Class