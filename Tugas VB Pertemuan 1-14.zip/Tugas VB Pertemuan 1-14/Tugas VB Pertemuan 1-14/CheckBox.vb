﻿Public Class FormChkBox
    Private Sub BtTampil_Click(sender As Object, e As EventArgs) Handles BtTampil.Click
        Dim pilihan As String
        pilihan = "Anda Memilih "
        If ChkSate.Checked = True Then
            pilihan = pilihan & "Sate"
        End If
        If ChkSoto.Checked = True Then
            pilihan = pilihan & "Soto"
        End If
        If ChkKare.Checked = True Then
            pilihan = pilihan & "Kare"
        End If
        MsgBox(pilihan & ", Pesanan segera diantar")
    End Sub
End Class