﻿Public Class FormComboBox
    Private Sub Form11_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ComboBox1.Items.Clear()
        ComboBox1.Items.Add("Paket 1")
        ComboBox1.Items.Add("Paket 2")
        ComboBox1.Items.Add("Paket 3")
        ComboBox1.Items.Add("Paket 4")
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        If ComboBox1.Text = "Paket 1" Then
            Me.TextBox1.Text = "Bakso"
            Me.TextBox2.Text = "Teh Manis"
            Me.TextBox3.Text = "11000"
        ElseIf ComboBox1.Text = "Paket 2" Then
            Me.TextBox1.Text = "Ayam Geprek"
            Me.TextBox2.Text = "Es Jeruk"
            Me.TextBox3.Text = "15000"
        ElseIf ComboBox1.Text = "Paket 3" Then
            Me.TextBox1.Text = "Nasi Goreng"
            Me.TextBox2.Text = "Es Teh"
            Me.TextBox3.Text = "10000"
        Else
            Me.TextBox1.Text = "Ayam Bakar"
            Me.TextBox2.Text = "Es Milo"
            Me.TextBox3.Text = "20000"
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ComboBox1.ResetText()
        TextBox6.ResetText()
        TextBox5.ResetText()
        TextBox3.ResetText()
        TextBox2.ResetText()
        TextBox1.ResetText()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim pesan As String
        pesan = MsgBox("Apa Anda Yakin Keluar??", MsgBoxStyle.Question + MsgBoxStyle.OkCancel, "Exit")
        If pesan = vbOK Then
            Me.Close()
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        TextBox6.Text = TextBox5.Text - TextBox3.Text
    End Sub
End Class