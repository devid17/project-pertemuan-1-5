﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FormMenuUtama
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.Pertemuan2ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PesanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Slide18ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Pertemuan2ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Slide7ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Slide12ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Slide14ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Slide15ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Slide16ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Pertemuan3ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Slide4ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Slide10ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Slide9ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Slide14ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Slide17ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EntryDataMahasiswaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenghitungNilaiMahasiswaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Pertemuan4ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CaseMenggunakanListBoxToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CaseMenggunakanButtonToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PenghitunganNilaiAkhirDanGradeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GajiKaryawanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Pertemuan5ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Slide3ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Slide4ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Slide5ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Slide6ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Pertemuan2ToolStripMenuItem, Me.Pertemuan2ToolStripMenuItem1, Me.Pertemuan3ToolStripMenuItem, Me.Pertemuan4ToolStripMenuItem1, Me.Pertemuan5ToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1370, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'Pertemuan2ToolStripMenuItem
        '
        Me.Pertemuan2ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PesanToolStripMenuItem, Me.Slide18ToolStripMenuItem})
        Me.Pertemuan2ToolStripMenuItem.Name = "Pertemuan2ToolStripMenuItem"
        Me.Pertemuan2ToolStripMenuItem.Size = New System.Drawing.Size(86, 20)
        Me.Pertemuan2ToolStripMenuItem.Text = "Pertemuan 1"
        '
        'PesanToolStripMenuItem
        '
        Me.PesanToolStripMenuItem.Name = "PesanToolStripMenuItem"
        Me.PesanToolStripMenuItem.Size = New System.Drawing.Size(114, 22)
        Me.PesanToolStripMenuItem.Text = "Pesan"
        '
        'Slide18ToolStripMenuItem
        '
        Me.Slide18ToolStripMenuItem.Name = "Slide18ToolStripMenuItem"
        Me.Slide18ToolStripMenuItem.Size = New System.Drawing.Size(114, 22)
        Me.Slide18ToolStripMenuItem.Text = "Pesan 2"
        '
        'Pertemuan2ToolStripMenuItem1
        '
        Me.Pertemuan2ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Slide7ToolStripMenuItem, Me.Slide12ToolStripMenuItem, Me.Slide14ToolStripMenuItem, Me.Slide15ToolStripMenuItem, Me.Slide16ToolStripMenuItem})
        Me.Pertemuan2ToolStripMenuItem1.Name = "Pertemuan2ToolStripMenuItem1"
        Me.Pertemuan2ToolStripMenuItem1.Size = New System.Drawing.Size(86, 20)
        Me.Pertemuan2ToolStripMenuItem1.Text = "Pertemuan 2"
        '
        'Slide7ToolStripMenuItem
        '
        Me.Slide7ToolStripMenuItem.Name = "Slide7ToolStripMenuItem"
        Me.Slide7ToolStripMenuItem.Size = New System.Drawing.Size(188, 22)
        Me.Slide7ToolStripMenuItem.Text = "Operator Relasi"
        '
        'Slide12ToolStripMenuItem
        '
        Me.Slide12ToolStripMenuItem.Name = "Slide12ToolStripMenuItem"
        Me.Slide12ToolStripMenuItem.Size = New System.Drawing.Size(188, 22)
        Me.Slide12ToolStripMenuItem.Text = "Kurs Mata Uang"
        '
        'Slide14ToolStripMenuItem
        '
        Me.Slide14ToolStripMenuItem.Name = "Slide14ToolStripMenuItem"
        Me.Slide14ToolStripMenuItem.Size = New System.Drawing.Size(188, 22)
        Me.Slide14ToolStripMenuItem.Text = "Operator Aritmatika 1"
        '
        'Slide15ToolStripMenuItem
        '
        Me.Slide15ToolStripMenuItem.Name = "Slide15ToolStripMenuItem"
        Me.Slide15ToolStripMenuItem.Size = New System.Drawing.Size(188, 22)
        Me.Slide15ToolStripMenuItem.Text = "Operator Aritmatika 2"
        '
        'Slide16ToolStripMenuItem
        '
        Me.Slide16ToolStripMenuItem.Name = "Slide16ToolStripMenuItem"
        Me.Slide16ToolStripMenuItem.Size = New System.Drawing.Size(188, 22)
        Me.Slide16ToolStripMenuItem.Text = "Konversi"
        '
        'Pertemuan3ToolStripMenuItem
        '
        Me.Pertemuan3ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Slide4ToolStripMenuItem, Me.Slide10ToolStripMenuItem, Me.Slide9ToolStripMenuItem, Me.Slide14ToolStripMenuItem1, Me.Slide17ToolStripMenuItem, Me.EntryDataMahasiswaToolStripMenuItem, Me.MenghitungNilaiMahasiswaToolStripMenuItem})
        Me.Pertemuan3ToolStripMenuItem.Name = "Pertemuan3ToolStripMenuItem"
        Me.Pertemuan3ToolStripMenuItem.Size = New System.Drawing.Size(83, 20)
        Me.Pertemuan3ToolStripMenuItem.Text = "Pertemuan3"
        '
        'Slide4ToolStripMenuItem
        '
        Me.Slide4ToolStripMenuItem.Name = "Slide4ToolStripMenuItem"
        Me.Slide4ToolStripMenuItem.Size = New System.Drawing.Size(255, 22)
        Me.Slide4ToolStripMenuItem.Text = "If Then"
        '
        'Slide10ToolStripMenuItem
        '
        Me.Slide10ToolStripMenuItem.Name = "Slide10ToolStripMenuItem"
        Me.Slide10ToolStripMenuItem.Size = New System.Drawing.Size(255, 22)
        Me.Slide10ToolStripMenuItem.Text = "If..Else..End If dengan CheckBox"
        '
        'Slide9ToolStripMenuItem
        '
        Me.Slide9ToolStripMenuItem.Name = "Slide9ToolStripMenuItem"
        Me.Slide9ToolStripMenuItem.Size = New System.Drawing.Size(255, 22)
        Me.Slide9ToolStripMenuItem.Text = "If..Else..End If dengan RadioButton"
        '
        'Slide14ToolStripMenuItem1
        '
        Me.Slide14ToolStripMenuItem1.Name = "Slide14ToolStripMenuItem1"
        Me.Slide14ToolStripMenuItem1.Size = New System.Drawing.Size(255, 22)
        Me.Slide14ToolStripMenuItem1.Text = "If..Else..End If dengan ComboBox"
        '
        'Slide17ToolStripMenuItem
        '
        Me.Slide17ToolStripMenuItem.Name = "Slide17ToolStripMenuItem"
        Me.Slide17ToolStripMenuItem.Size = New System.Drawing.Size(255, 22)
        Me.Slide17ToolStripMenuItem.Text = "Nested If"
        '
        'EntryDataMahasiswaToolStripMenuItem
        '
        Me.EntryDataMahasiswaToolStripMenuItem.Name = "EntryDataMahasiswaToolStripMenuItem"
        Me.EntryDataMahasiswaToolStripMenuItem.Size = New System.Drawing.Size(255, 22)
        Me.EntryDataMahasiswaToolStripMenuItem.Text = "Entry Data Mahasiswa"
        '
        'MenghitungNilaiMahasiswaToolStripMenuItem
        '
        Me.MenghitungNilaiMahasiswaToolStripMenuItem.Name = "MenghitungNilaiMahasiswaToolStripMenuItem"
        Me.MenghitungNilaiMahasiswaToolStripMenuItem.Size = New System.Drawing.Size(255, 22)
        Me.MenghitungNilaiMahasiswaToolStripMenuItem.Text = "Menghitung Nilai Mahasiswa"
        '
        'Pertemuan4ToolStripMenuItem1
        '
        Me.Pertemuan4ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CaseMenggunakanListBoxToolStripMenuItem, Me.ToolStripMenuItem1, Me.ToolStripMenuItem2, Me.CaseMenggunakanButtonToolStripMenuItem, Me.PenghitunganNilaiAkhirDanGradeToolStripMenuItem, Me.GajiKaryawanToolStripMenuItem})
        Me.Pertemuan4ToolStripMenuItem1.Name = "Pertemuan4ToolStripMenuItem1"
        Me.Pertemuan4ToolStripMenuItem1.Size = New System.Drawing.Size(86, 20)
        Me.Pertemuan4ToolStripMenuItem1.Text = "Pertemuan 4"
        '
        'CaseMenggunakanListBoxToolStripMenuItem
        '
        Me.CaseMenggunakanListBoxToolStripMenuItem.Name = "CaseMenggunakanListBoxToolStripMenuItem"
        Me.CaseMenggunakanListBoxToolStripMenuItem.Size = New System.Drawing.Size(292, 22)
        Me.CaseMenggunakanListBoxToolStripMenuItem.Text = "Case Menggunakan ListBox"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(292, 22)
        Me.ToolStripMenuItem1.Text = "Case Menggunakan ComboBox"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(292, 22)
        Me.ToolStripMenuItem2.Text = "Case Menggunakan TextBox"
        '
        'CaseMenggunakanButtonToolStripMenuItem
        '
        Me.CaseMenggunakanButtonToolStripMenuItem.Name = "CaseMenggunakanButtonToolStripMenuItem"
        Me.CaseMenggunakanButtonToolStripMenuItem.Size = New System.Drawing.Size(292, 22)
        Me.CaseMenggunakanButtonToolStripMenuItem.Text = "Case Menggunakan Button"
        '
        'PenghitunganNilaiAkhirDanGradeToolStripMenuItem
        '
        Me.PenghitunganNilaiAkhirDanGradeToolStripMenuItem.Name = "PenghitunganNilaiAkhirDanGradeToolStripMenuItem"
        Me.PenghitunganNilaiAkhirDanGradeToolStripMenuItem.Size = New System.Drawing.Size(292, 22)
        Me.PenghitunganNilaiAkhirDanGradeToolStripMenuItem.Text = "Case Penghitungan Nilai Akhir dan Grade"
        '
        'GajiKaryawanToolStripMenuItem
        '
        Me.GajiKaryawanToolStripMenuItem.Name = "GajiKaryawanToolStripMenuItem"
        Me.GajiKaryawanToolStripMenuItem.Size = New System.Drawing.Size(292, 22)
        Me.GajiKaryawanToolStripMenuItem.Text = "Case Gaji Karyawan"
        '
        'Pertemuan5ToolStripMenuItem
        '
        Me.Pertemuan5ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Slide3ToolStripMenuItem, Me.Slide4ToolStripMenuItem1, Me.Slide5ToolStripMenuItem, Me.Slide6ToolStripMenuItem, Me.ToolStripMenuItem3})
        Me.Pertemuan5ToolStripMenuItem.Name = "Pertemuan5ToolStripMenuItem"
        Me.Pertemuan5ToolStripMenuItem.Size = New System.Drawing.Size(86, 20)
        Me.Pertemuan5ToolStripMenuItem.Text = "Pertemuan 5"
        '
        'Slide3ToolStripMenuItem
        '
        Me.Slide3ToolStripMenuItem.Name = "Slide3ToolStripMenuItem"
        Me.Slide3ToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.Slide3ToolStripMenuItem.Text = "Perulangan for-next"
        '
        'Slide4ToolStripMenuItem1
        '
        Me.Slide4ToolStripMenuItem1.Name = "Slide4ToolStripMenuItem1"
        Me.Slide4ToolStripMenuItem1.Size = New System.Drawing.Size(194, 22)
        Me.Slide4ToolStripMenuItem1.Text = "Perulangan for-next -1"
        '
        'Slide5ToolStripMenuItem
        '
        Me.Slide5ToolStripMenuItem.Name = "Slide5ToolStripMenuItem"
        Me.Slide5ToolStripMenuItem.Size = New System.Drawing.Size(223, 22)
        Me.Slide5ToolStripMenuItem.Text = "Perulangan for-next tanggal"
        '
        'Slide6ToolStripMenuItem
        '
        Me.Slide6ToolStripMenuItem.Name = "Slide6ToolStripMenuItem"
        Me.Slide6ToolStripMenuItem.Size = New System.Drawing.Size(223, 22)
        Me.Slide6ToolStripMenuItem.Text = "Perulangan for-next jumlah"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(223, 22)
        Me.ToolStripMenuItem3.Text = "Latihan 1"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Navy
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.Yellow
        Me.Button1.Location = New System.Drawing.Point(947, 638)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(106, 48)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Exit"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Black
        Me.Label1.Font = New System.Drawing.Font("Century Schoolbook", 48.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Yellow
        Me.Label1.Location = New System.Drawing.Point(436, 116)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(472, 76)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "TEAM NAME"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Black
        Me.Label2.Font = New System.Drawing.Font("Century Schoolbook", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Yellow
        Me.Label2.Location = New System.Drawing.Point(565, 235)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(204, 33)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Devid Prasetio"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Black
        Me.Label3.Font = New System.Drawing.Font("Century Schoolbook", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Yellow
        Me.Label3.Location = New System.Drawing.Point(488, 285)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(356, 33)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Irnaldika Inzagia Pratama"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Black
        Me.Label4.Font = New System.Drawing.Font("Century Schoolbook", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Yellow
        Me.Label4.Location = New System.Drawing.Point(543, 385)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(247, 33)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Novia Sukmadewi"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Black
        Me.Label5.Font = New System.Drawing.Font("Century Schoolbook", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Yellow
        Me.Label5.Location = New System.Drawing.Point(522, 439)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(295, 33)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Oswald Motani Zebua"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Black
        Me.Label6.Font = New System.Drawing.Font("Century Schoolbook", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Yellow
        Me.Label6.Location = New System.Drawing.Point(532, 488)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(262, 33)
        Me.Label6.TabIndex = 7
        Me.Label6.Text = "Rikardo Sihombing"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Black
        Me.Label7.Font = New System.Drawing.Font("Century Schoolbook", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Yellow
        Me.Label7.Location = New System.Drawing.Point(488, 334)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(362, 33)
        Me.Label7.TabIndex = 8
        Me.Label7.Text = "Muhammad Dody Prasetyo"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Black
        Me.Label8.Font = New System.Drawing.Font("Century Schoolbook", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Yellow
        Me.Label8.Location = New System.Drawing.Point(515, 538)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(302, 33)
        Me.Label8.TabIndex = 9
        Me.Label8.Text = "Ronaldo Baja Pradana"
        '
        'FormMenuUtama
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.BackgroundImage = Global.Tugas_VB_Pertemuan_1_14.My.Resources.Resources.de4c59728beea8bfe5d175b006be6ec61
        Me.ClientSize = New System.Drawing.Size(1370, 740)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.ForeColor = System.Drawing.Color.Navy
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "FormMenuUtama"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Menu Utama"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents Pertemuan2ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PesanToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Slide18ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Pertemuan2ToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents Slide7ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Slide12ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Slide14ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Slide15ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Slide16ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Pertemuan3ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Slide4ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Slide9ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Slide10ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Slide14ToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents Slide17ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EntryDataMahasiswaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MenghitungNilaiMahasiswaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Pertemuan4ToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents CaseMenggunakanListBoxToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents CaseMenggunakanButtonToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PenghitunganNilaiAkhirDanGradeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents GajiKaryawanToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Button1 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Pertemuan5ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Slide3ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Slide4ToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents Slide5ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Slide6ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As ToolStripMenuItem
End Class
