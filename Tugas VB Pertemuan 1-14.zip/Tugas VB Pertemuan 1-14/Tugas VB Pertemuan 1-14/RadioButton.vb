﻿Public Class FormRadioButton

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles BtTampil.Click
        Dim pilihan As String
        pilihan = "Anda Memilih "
        If RBSate.Checked = True Then
            pilihan = pilihan & "Sate"
        End If
        If RBSoto.Checked = True Then
            pilihan = pilihan & "Soto"
        End If
        If RBKare.Checked = True Then
            pilihan = pilihan & "Kare"
        End If
        MsgBox(pilihan & ", Pesanan segera diantar")
    End Sub
End Class