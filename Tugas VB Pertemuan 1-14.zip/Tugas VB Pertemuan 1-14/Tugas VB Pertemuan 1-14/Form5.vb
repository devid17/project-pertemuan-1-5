﻿Public Class Platihan
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim Awal As Integer
        Dim Akhir As Integer
        Dim langkah As Integer

        Awal = BAwal.Text
        Akhir = BAkhir.Text
        langkah = TStep.Text

        For i = Awal To Akhir Step +langkah
            ListBox1.Items.Add(i)
        Next
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        BAwal.Text = ""
        BAkhir.Text = ""
        TStep.Text = ""
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Close()
    End Sub
End Class