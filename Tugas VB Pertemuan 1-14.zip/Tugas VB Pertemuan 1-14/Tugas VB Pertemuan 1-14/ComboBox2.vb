﻿Public Class FormCaseCmb
    Private Sub Form16_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ComboBox1.Items.Clear()
        ComboBox1.Items.Add("Paket 1")
        ComboBox1.Items.Add("Paket 2")
        ComboBox1.Items.Add("Paket 3")
        ComboBox1.Items.Add("Paket 4")
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        Select Case (Me.ComboBox1.Text)
            Case ("Paket 1")
                Me.TextBox1.Text = "Rendang"
                Me.TextBox2.Text = "Teh Manis"
                Me.TextBox3.Text = "11000"
            Case ("Paket 2")
                Me.TextBox1.Text = "Ayam Goreng"
                Me.TextBox2.Text = "Juice Jeruk"
                Me.TextBox3.Text = "15000"
            Case ("Paket 3")
                Me.TextBox1.Text = "Nasi Goreng"
                Me.TextBox2.Text = "Es Teh"
                Me.TextBox3.Text = "8000"
            Case ("Paket 4")
                Me.TextBox1.Text = "Nasi Bakar"
                Me.TextBox2.Text = "Kopi"
                Me.TextBox3.Text = "17000"
        End Select
    End Sub
End Class