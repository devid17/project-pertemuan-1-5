﻿Public Class FormButton
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Select Case Val(TxtAngka.Text)
            Case 80 To 100
                LblNilai.Text = "A"
                LblKet.Text = "Memuaskan"
            Case 70 To 79
                LblNilai.Text = "B"
                LblKet.Text = "Baik"
            Case 60 To 69
                LblNilai.Text = "C"
                LblKet.Text = "Cukup"
            Case 50 To 59
                LblNilai.Text = "D"
                LblKet.Text = "Kurang"
            Case 0 To 49
                LblNilai.Text = "E"
                LblKet.Text = "Gagal"
            Case Else
                MsgBox("Nilai angkanya salah", "Nilai Salah", MsgBoxStyle.OkOnly + MsgBoxStyle.Information)
        End Select
    End Sub
End Class