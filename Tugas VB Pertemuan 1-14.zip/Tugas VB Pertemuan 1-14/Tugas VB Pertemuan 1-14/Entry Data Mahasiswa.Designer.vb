﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormEntryData
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.LblGender = New System.Windows.Forms.Label()
        Me.LblJur = New System.Windows.Forms.Label()
        Me.LblNama = New System.Windows.Forms.Label()
        Me.LblNpm = New System.Windows.Forms.Label()
        Me.CmdProses = New System.Windows.Forms.Button()
        Me.RbW = New System.Windows.Forms.RadioButton()
        Me.RbP = New System.Windows.Forms.RadioButton()
        Me.CmbJur = New System.Windows.Forms.ComboBox()
        Me.TxtNama = New System.Windows.Forms.TextBox()
        Me.TxtNPM = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.LblGender)
        Me.GroupBox1.Controls.Add(Me.LblJur)
        Me.GroupBox1.Controls.Add(Me.LblNama)
        Me.GroupBox1.Controls.Add(Me.LblNpm)
        Me.GroupBox1.Controls.Add(Me.CmdProses)
        Me.GroupBox1.Controls.Add(Me.RbW)
        Me.GroupBox1.Controls.Add(Me.RbP)
        Me.GroupBox1.Controls.Add(Me.CmbJur)
        Me.GroupBox1.Controls.Add(Me.TxtNama)
        Me.GroupBox1.Controls.Add(Me.TxtNPM)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(557, 426)
        Me.GroupBox1.TabIndex = 22
        Me.GroupBox1.TabStop = False
        '
        'LblGender
        '
        Me.LblGender.AutoSize = True
        Me.LblGender.Location = New System.Drawing.Point(14, 343)
        Me.LblGender.Name = "LblGender"
        Me.LblGender.Size = New System.Drawing.Size(0, 13)
        Me.LblGender.TabIndex = 38
        '
        'LblJur
        '
        Me.LblJur.AutoSize = True
        Me.LblJur.Location = New System.Drawing.Point(14, 301)
        Me.LblJur.Name = "LblJur"
        Me.LblJur.Size = New System.Drawing.Size(0, 13)
        Me.LblJur.TabIndex = 37
        '
        'LblNama
        '
        Me.LblNama.AutoSize = True
        Me.LblNama.Location = New System.Drawing.Point(14, 259)
        Me.LblNama.Name = "LblNama"
        Me.LblNama.Size = New System.Drawing.Size(0, 13)
        Me.LblNama.TabIndex = 36
        '
        'LblNpm
        '
        Me.LblNpm.AutoSize = True
        Me.LblNpm.Location = New System.Drawing.Point(14, 223)
        Me.LblNpm.Name = "LblNpm"
        Me.LblNpm.Size = New System.Drawing.Size(0, 13)
        Me.LblNpm.TabIndex = 35
        '
        'CmdProses
        '
        Me.CmdProses.Location = New System.Drawing.Point(152, 185)
        Me.CmdProses.Name = "CmdProses"
        Me.CmdProses.Size = New System.Drawing.Size(75, 23)
        Me.CmdProses.TabIndex = 34
        Me.CmdProses.Text = "Proses"
        Me.CmdProses.UseVisualStyleBackColor = True
        '
        'RbW
        '
        Me.RbW.AutoSize = True
        Me.RbW.Location = New System.Drawing.Point(204, 132)
        Me.RbW.Name = "RbW"
        Me.RbW.Size = New System.Drawing.Size(59, 17)
        Me.RbW.TabIndex = 33
        Me.RbW.TabStop = True
        Me.RbW.Text = "Wanita"
        Me.RbW.UseVisualStyleBackColor = True
        '
        'RbP
        '
        Me.RbP.AutoSize = True
        Me.RbP.Location = New System.Drawing.Point(91, 132)
        Me.RbP.Name = "RbP"
        Me.RbP.Size = New System.Drawing.Size(43, 17)
        Me.RbP.TabIndex = 32
        Me.RbP.TabStop = True
        Me.RbP.Text = "Pria"
        Me.RbP.UseVisualStyleBackColor = True
        '
        'CmbJur
        '
        Me.CmbJur.FormattingEnabled = True
        Me.CmbJur.Location = New System.Drawing.Point(91, 94)
        Me.CmbJur.Name = "CmbJur"
        Me.CmbJur.Size = New System.Drawing.Size(203, 21)
        Me.CmbJur.TabIndex = 31
        '
        'TxtNama
        '
        Me.TxtNama.Location = New System.Drawing.Point(91, 55)
        Me.TxtNama.Name = "TxtNama"
        Me.TxtNama.Size = New System.Drawing.Size(203, 20)
        Me.TxtNama.TabIndex = 30
        '
        'TxtNPM
        '
        Me.TxtNPM.Location = New System.Drawing.Point(91, 16)
        Me.TxtNPM.Name = "TxtNPM"
        Me.TxtNPM.Size = New System.Drawing.Size(112, 20)
        Me.TxtNPM.TabIndex = 29
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(27, 132)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(42, 13)
        Me.Label4.TabIndex = 28
        Me.Label4.Text = "Gender"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(27, 94)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 13)
        Me.Label3.TabIndex = 27
        Me.Label3.Text = "Jurusan"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(27, 55)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(35, 13)
        Me.Label2.TabIndex = 26
        Me.Label2.Text = "Nama"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(27, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 13)
        Me.Label1.TabIndex = 25
        Me.Label1.Text = "Npm"
        '
        'FormEntryData
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Tugas_VB_Pertemuan_1_14.My.Resources.Resources._803_x_450_
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "FormEntryData"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Program Entry Data Mahasiswa"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents LblGender As Label
    Friend WithEvents LblJur As Label
    Friend WithEvents LblNama As Label
    Friend WithEvents LblNpm As Label
    Friend WithEvents CmdProses As Button
    Friend WithEvents RbW As RadioButton
    Friend WithEvents RbP As RadioButton
    Friend WithEvents CmbJur As ComboBox
    Friend WithEvents TxtNama As TextBox
    Friend WithEvents TxtNPM As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
End Class
