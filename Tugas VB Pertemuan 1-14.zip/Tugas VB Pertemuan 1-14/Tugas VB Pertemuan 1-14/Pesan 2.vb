﻿Public Class FormPesan2
    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        If TextBox1.Text = "" Then
            MsgBox("isi dulu Nama anda")
        Else
            MsgBox("Nama : " + TextBox1.Text & vbNewLine & "Npm : " + TextBox2.Text & vbNewLine & "Prodi : " + TextBox3.Text & vbNewLine &
                   "Mata Kuliah : " + TextBox4.Text)
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        MsgBox("Mencoba Belajar Visual Basic")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        MsgBox("Contoh Tanda Seru", MsgBoxStyle.Exclamation, "Baca Pesan")
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        MsgBox("Tanda Information", MsgBoxStyle.Information, "Baca Pesan")
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        MsgBox("Contoh Tanda Error", MsgBoxStyle.Critical, "Baca Pesan")
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Me.Close()
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Label1.Text = ""
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Label1.Text = "Percobaan Visual Basic"
        Label1.ForeColor = Color.Yellow
        Button5.Text = "OK...!!!"
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim pesan As String
        pesan = MsgBox("Apakah Anda Ingin Keluar Dari Program??", MsgBoxStyle.Question + MsgBoxStyle.OkCancel, "Exit")
        If pesan = vbOK Then
            Me.Close()
        End If
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        End
    End Sub
End Class