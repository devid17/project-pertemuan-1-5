﻿Public Class FormListBox
    Private Sub Form15_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ListBox1.Items.Add("Jeruk")
        ListBox1.Items.Add("Alpukat")
        ListBox1.Items.Add("Strawberry")
        ListBox1.Items.Add("Semangka")
        ListBox1.Items.Add("Lengkeng")
        ListBox1.Items.Add("Kedongdong")
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged
        Select Case ListBox1.SelectedIndex
            Case 0
                Label3.Text = "Banyak mengandung vitamin C."
            Case 1
                Label3.Text = "Salah satu buah yang mengandung lemak... "
            Case 2
                Label3.Text = "Hanya tumbuh di dataran tinggi."
            Case 3
                Label3.Text = "Buah berair.. Enak dimakan saat cuaca panas."
            Case 4
                Label3.Text = "Rasa buah ini manis."
            Case 5
                Label3.Text = "Enak kalau dibuat rujak..."

        End Select
    End Sub
End Class