﻿Public Class FormKonversi

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        Dim harga, jumlah, total As Integer

        harga = CInt(TextBox2.Text)
        jumlah = CInt(TextBox3.Text)

        total = harga * jumlah

        TextBox4.Text = CStr(total)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If TextBox4.Text <= TextBox5.Text Then
            TextBox6.Text = TextBox5.Text - TextBox4.Text
        ElseIf TextBox4.Text > TextBox5.Text Then
            MsgBox("Maaf, uang anda tidak mencukupi pembelian", MsgBoxStyle.Exclamation, "Pesan")
        End If
    End Sub
End Class